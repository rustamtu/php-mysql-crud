<?php
// postmethod.php
echo json_encode($_POST);