<?php
$data = [
    'status' => 1,
    'message' => 'Its for testing'
];

echo json_encode($data);
